﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pile1BehaviorScript : MonoBehaviour, PileInteractionScript {

    public Color redColor = Color.red;
    public Rigidbody rb;
    public Rigidbody medRb;
    public Rigidbody largeRb;

    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}

    public void onEleOnePickup()
    {
        PlayerController p = GetComponent<PlayerController>();
        p.rend.material.color = Color.red;//p.colorTwo;
        MediumStateScript mss = GetComponent<MediumStateScript>();
        LargeStateScript lss = GetComponent<LargeStateScript>();
        rb.gameObject.GetComponent<Renderer>().material.color = redColor;

        if (mss.medRb)
        {
            p.medBody.GetComponent<Renderer>().sharedMaterial.color = redColor;
        }
        if (lss.largeRb)
        {
            p.largeBody.GetComponent<Renderer>().sharedMaterial.color = redColor;
        }
    }
    public void onEleTwoPickup() { }
}
