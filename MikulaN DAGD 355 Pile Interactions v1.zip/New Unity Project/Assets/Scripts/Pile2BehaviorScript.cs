﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pile2BehaviorScript : MonoBehaviour, PileInteractionScript
{
    public Color blueColor = Color.blue;
    public Rigidbody rb;
    public Rigidbody medRb;
    public Rigidbody largeRb;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void onEleOnePickup() { }

    public void onEleTwoPickup()
    {
        PlayerController p = GetComponent<PlayerController>();
        MediumStateScript mss = GetComponent<MediumStateScript>();
        LargeStateScript lss = GetComponent<LargeStateScript>();
        p.rend.material.color = Color.blue;//p.colorOne;
        rb.gameObject.GetComponent<Renderer>().material.color = Color.blue;

        if (mss.medRb)
        {
            p.medBody.GetComponent<Renderer>().sharedMaterial.color = blueColor;
        }
        if (lss.largeRb)
        {
            p.largeBody.GetComponent<Renderer>().sharedMaterial.color = blueColor;
        }
    }
}
