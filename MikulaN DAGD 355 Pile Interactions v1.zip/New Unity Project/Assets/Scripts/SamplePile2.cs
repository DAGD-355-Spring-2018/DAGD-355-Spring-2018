﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Using Austin's pickup script as base

public class SamplePile2 : MonoBehaviour
{

    private GameObject player;

    // Use this for initialization
    void Awake()
    {
        player = GameObject.Find("Clayton");
        //Debug.Log (player);
    }

    private void OnTriggerEnter(Collider other)
    {
        onTrigger();
    }

    void OnTriggerStay(Collider other)
    {
        onTrigger();
    }

    private void OnTriggerExit(Collider other)
    {
        //CameraController.isTriggered = false; // commented this out, this isn't necessary because of how this is set up
    }

    private void onTrigger()
    {
        //bool isEligible = player.GetComponent<MediumStateScript>().enabled;// checks if it is in the medium state, small and large cant pick this up
       // if (isEligible) // if its medium
        //{
            CameraController.uiText.SetActive(true);
            CameraController.isTriggered = true; // tells camera controller that there is atleast 1 pickup that is in range of the player
            if (Input.GetKeyDown(KeyCode.E))
            {
            //player.GetComponent<PlayerController>().sizeState.onLargePickup(); // calls the medium states on large pickup function (changes into large state)
                player.GetComponent<PlayerController>().pileScript2.onEleTwoPickup();
                //Destroy(gameObject);  // destroys this gameobject
            }
       // }
    }
}
