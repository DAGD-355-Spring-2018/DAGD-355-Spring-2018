﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

//Using Austin's pickup script as base
public class PlayerController : MonoBehaviour {


    public GameObject medBody; // prefab for med body
    public GameObject largeBody; // prefab for large body
    public GameObject smallPickup; // prefab for small pickup
	public GameObject largePickup; // prefab for large pickup
    public GameObject samplePile1;
    public GameObject samplePile2;
    //public Color colorOne = Color.red;
    //public Color colorTwo = Color.blue;

    static public bool isGrounded; // dumb way of controlling physics, this is just for the eject/growing phases, dont use these movement and physics controls, they are garbage
    public float speed;
    public float jumpStrength;
    public Renderer rend;

	public SizeState sizeState; // What state is currently active (TinyStateScript, MediumStateScript, or LargeStateScript)
    public PileInteractionScript pileInteractionScript;
    public PileInteractionScript pileScript2;

    private void Start()
    {
        sizeState = GetComponent<TinyStateScript>();
        pileInteractionScript = GetComponent<Pile1BehaviorScript>();
        pileScript2 = GetComponent<Pile2BehaviorScript>();
        GetComponent<MediumStateScript>().enabled = false;
        GetComponent<LargeStateScript>().enabled = false;
        rend = GetComponent<Renderer>();
    }
    private void Update() // could probably have an if else chain here to see what state its in to figure out what physics body to move
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            sizeState.eject(); // if the space bar is pressed, call the states eject function
        }
    }
}
