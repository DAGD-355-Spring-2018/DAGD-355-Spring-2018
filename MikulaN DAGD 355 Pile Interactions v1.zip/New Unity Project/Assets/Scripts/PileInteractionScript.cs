﻿using UnityEngine;

//this can probably be merged with SizeState into one State Machine.
public interface PileInteractionScript
{

    // called when an element pile is picked up; rename as necessary
    void onEleOnePickup();
    void onEleTwoPickup();
}