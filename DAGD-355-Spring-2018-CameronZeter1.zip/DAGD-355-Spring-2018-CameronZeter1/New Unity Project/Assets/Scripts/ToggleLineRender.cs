﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToggleLineRender : MonoBehaviour {

    LineRenderer LR;
    public GameObject player;
    public GameObject parent;
    public Vector3 offset;
    Vector3 hit;

    Vector3 fwd;

    public bool isTouchingLight;

    public LayerMask groundLayer = 1 << 8;

    // Use this for initialization
    void Start() {
        LR = GetComponent<LineRenderer>();
    }

    // Update is called once per frame
    void Update() {
        LR.enabled = false;

        LR.SetPosition(0, parent.transform.position);

        fwd = transform.TransformDirection(Vector3.forward);
        //Debug.DrawRay(parent.transform.position, fwd * 100, Color.green);

        if (!player.GetComponent<TinyStateScript>().enabled)
        {
            if (isTouchingLight)
            {
                ShootRay();
                LR.enabled = true;
                //Debug.Log("on");


            }
            else
            {
                LR.enabled = false;
                //Debug.Log("off");
                LR.SetPosition(1, parent.transform.position);
            }
        }

        
    }

    void LateUpdate()
    {

       // transform.position = parent.transform.position;
    }

    void ShootRay() {
        RaycastHit Hit;

        
       // Debug.Log("shoot");
        if (Physics.Raycast(parent.transform.position, fwd * 100, out Hit))
        {
            Debug.Log(Hit.transform.name);
            

            Vector3 hitPosition = fwd * 10;
            LR.SetPosition(1, hitPosition);


        }
    }
}
