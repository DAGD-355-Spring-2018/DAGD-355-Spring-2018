﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Emitter : MonoBehaviour
{
    LineRenderer lr;
    public GameObject emitter;

    private int playerLayer = (1 << 9);
    public GameObject claytonObject;


    Vector3 hit;

    Vector3 fwd;


    // Use this for initialization
    void Start()
    {
        lr = GetComponent<LineRenderer>();
        
    }

    // Update is called once per frame
    void Update()
    {
        fwd = transform.TransformDirection(Vector3.forward);

        lr.SetPosition(0, emitter.transform.position);

        RaycastHit Hit;


        // Debug.Log("shoot");
        if (Physics.Raycast(emitter.transform.position, fwd * 100, out Hit, 100, playerLayer))
        {
            Debug.Log(Hit.transform.name);

            Debug.DrawRay(emitter.transform.position, fwd * 100, Color.green);

            Vector3 hitPosition = Hit.transform.position;
            lr.SetPosition(1, hitPosition);
            claytonObject.isTouchingLight = true;
            

        }
        else
        {
            lr.SetPosition(1, fwd * 10);
            Debug.Log("does not hit");
        }

    }
}
