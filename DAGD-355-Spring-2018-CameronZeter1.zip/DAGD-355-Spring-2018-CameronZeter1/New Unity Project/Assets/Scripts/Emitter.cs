﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Emitter : MonoBehaviour
{
    LineRenderer lr;
    public GameObject emitter;

    public LayerMask playerBodyLayer;
    public GameObject claytonBeam;

    Vector3 hit;

    Vector3 fwd;


    // Use this for initialization
    void Start()
    {
        lr = GetComponent<LineRenderer>();

    }

    // Update is called once per frame
    void LateUpdate()
    {
        fwd = transform.TransformDirection(Vector3.forward);

        lr.SetPosition(0, emitter.transform.position);
        lr.SetPosition(1, emitter.transform.position);
        lr.SetPosition(2, emitter.transform.position);
        lr.SetPosition(3, emitter.transform.position);

        RaycastHit Hit;

        if (Physics.Raycast(emitter.transform.position, fwd, out Hit, 100, playerBodyLayer))
        {            
            if (Hit.collider.gameObject.tag == "Player Body")
            {
                lr.SetPosition(1, Hit.transform.position);
                fwd = claytonBeam.transform.TransformDirection(Vector3.forward);

                if (Physics.Raycast(Hit.transform.position, fwd, out Hit, 100, playerBodyLayer))
                {
                    if (Hit.collider.gameObject.tag == "Text")
                    {
                        lr.SetPosition(2, Hit.transform.position);
                        fwd = Hit.transform.TransformDirection(Vector3.forward);

                        if (Physics.Raycast(emitter.transform.position, fwd, out Hit, 100, playerBodyLayer))
                        {
                            if (Hit.collider.gameObject.tag == "Text")
                            {
                                lr.SetPosition(3, Hit.transform.position);
                            }
                        }

                        else
                        {
                            lr.SetPosition(3, fwd * 100);
                        }
                    }                    
                }

                else
                {
                    lr.SetPosition(2, fwd * 100);
                    lr.SetPosition(3, fwd * 100);                 
                }
            } 

            else if (Hit.collider.gameObject.tag == "Text")
            {
                lr.SetPosition(1, Hit.transform.position);
                fwd = Hit.transform.TransformDirection(Vector3.forward);

                if (Physics.Raycast(Hit.transform.position, fwd, out Hit, 100, playerBodyLayer))
                {
                    if (Hit.collider.gameObject.tag == "Text")
                    {
                        lr.SetPosition(2, Hit.transform.position);
                        fwd = Hit.transform.TransformDirection(Vector3.forward);

                        if (Physics.Raycast(Hit.transform.position, fwd, out Hit, 100, playerBodyLayer))
                        {
                            if (Hit.collider.gameObject.tag == "Text")
                            {
                                Vector3 hitPos = Hit.transform.position;
                                lr.SetPosition(3, hitPos);
                            } 

                            else if(Hit.collider.gameObject.tag == "Player Body")
                            {
                                Vector3 hitPos = Hit.transform.position;
                                lr.SetPosition(3, hitPos);
                            } 

                            else
                            {
                                lr.SetPosition(3, Hit.transform.position);
                            }
                        }

                        else
                        {
                            lr.SetPosition(3, fwd * 100);
                        }
                    }

                    else if (Hit.collider.gameObject.tag == "Player Body")
                    {
                        lr.SetPosition(2, Hit.transform.position);
                        fwd = claytonBeam.transform.TransformDirection(Vector3.forward);

                        if (Physics.Raycast(emitter.transform.position, fwd, out Hit, 100, playerBodyLayer))
                        {
                            if (Hit.collider.gameObject.tag == "Text")
                            {
                                lr.SetPosition(3, Hit.transform.position);
                            }
                        }

                        else
                        {
                            lr.SetPosition(3, fwd * 100);
                        } 
                    }

                    else
                    {
                        lr.SetPosition(2, Hit.transform.position);
                        lr.SetPosition(3, Hit.transform.position);
                    }
                }

                else
                {
                    lr.SetPosition(2, fwd * 100);
                }
            }

            else
            {             
                lr.SetPosition(1, Hit.transform.position);
            }
        }

        else
        {
            lr.SetPosition(1, fwd * 100);
            lr.SetPosition(2, fwd * 100);
            lr.SetPosition(3, fwd * 100);
        }
    }
}
