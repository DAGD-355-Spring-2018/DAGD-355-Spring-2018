﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneStateScript : ElementalState {
	
	public override void specialAbility()
	{
		Debug.Log ("Stone ability");
	}
}
