﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ElementalState : MonoBehaviour {

	public virtual void specialAbility()
	{
		Debug.Log ("Special Ability");
	}
}
