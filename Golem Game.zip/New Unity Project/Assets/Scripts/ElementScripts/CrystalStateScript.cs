﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrystalStateScript : ElementalState {

	public override void specialAbility()
	{
		Debug.Log ("Crystal ability");
	}
}
