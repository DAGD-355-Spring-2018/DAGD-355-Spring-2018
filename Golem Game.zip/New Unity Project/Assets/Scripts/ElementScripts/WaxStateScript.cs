﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaxStateScript : ElementalState {

	public override void specialAbility()
	{
		Debug.Log ("Wax ability");
	}
}
