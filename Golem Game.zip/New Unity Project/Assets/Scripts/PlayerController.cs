﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {


    public GameObject waxMedBody; // prefab for med body
	public GameObject woodMedBody; // prefab for med body
	public GameObject stoneMedBody; // prefab for med body
	public GameObject crystalMedBody; // prefab for med body
    public GameObject waxLargeBody; // prefab for large body
	public GameObject woodLargeBody;
	public GameObject stoneLargeBody; // prefab for large body
	public GameObject crystalLargeBody;

    static public bool isGrounded; // dumb way of controlling physics, this is just for the eject/growing phases, dont use these movement and physics controls, they are garbage
    //public float speed;
    public float jumpStrength;

	// My old Player Controller, just incase i want to go back

    /*public SizeState sizeState; // What state is currently active (TinyStateScript, MediumStateScript, or LargeStateScript)

	public GolemController golemController;

    private void Start()
    {
		sizeState = GameObject.Find("ClaytonHead").GetComponent<TinyStateScript>();
        //GetComponent<MediumStateScript>().enabled = false;
        //GetComponent<LargeStateScript>().enabled = false;
    }

    private void Update() // could probably have an if else chain here to see what state its in to figure out what physics body to move
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            sizeState.eject(); // if the space bar is pressed, call the states eject function
        }
    }

	void FixedUpdate()
	{
		Vector3 movement = new Vector3 ();

		movement.x = Input.GetAxis ("Horizontal");
		movement.z = Input.GetAxis ("Vertical");

		if (movement.magnitude > 1)
			movement.Normalize ();

		movement *= speed;

		gameObject.transform.Translate (movement);
	}*/

    public GolemController gCon; // current golemController
    public List<GameObject> bodyList; // list of bodies in clayton, max 3
    public float speed = 10;
    float moveX;
    float moveY;
    Rigidbody rb;

    // Use this for initialization
    void Start()
    {
        rb = GetComponent<Rigidbody>();
		bodyList.Add(GameObject.Find("ClaytonHead"));
        UpdateCurrentState();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Fire1"))
        {
            gCon.elementalState.specialAbility();
            //bodyList[bodyList.Count - 1].eState.Action();
        }
        if (Input.GetButtonDown("Fire2"))
        {
            gCon.sizeState.ability();
            //bodyList[bodyList.Count - 1].sState.Action();
        }
        if (Input.GetButtonDown("Jump"))
        {
            Eject();
        }
        moveX = Input.GetAxis("Horizontal");
        moveY = Input.GetAxis("Vertical");

    }
    void FixedUpdate()
    {
        rb.AddForce(new Vector3(moveX, 0, moveY) * speed);
    }
    /*public void OnCollisionStay(Collision c)
    {
		if (c.transform.CompareTag("Interactable"))
        {
            //Debug.Log("touching interactable");
            if (Input.GetButton("Fire3"))
            {
                c.transform.GetComponent<Interactable>().Interact(this);
                Debug.Log("pickup");
            }
        }

    }*/

    public void Eject()
    {
		rb.velocity = new Vector3(0,gCon.sizeState.jumpSrength,0); // jumps
        gCon.sizeState.eject(); // calls the size states eject
        if (bodyList.Count > 1) // if its not small
        {
			Destroy (bodyList [bodyList.Count - 1]); // destroy the current body
            bodyList.RemoveAt(bodyList.Count - 1); // removes it from the list
            UpdateCurrentState();  // updates
        }
    }

    public void UpdateCurrentState()
    {
        gCon = bodyList[bodyList.Count - 1].GetComponent<GolemController>();
    }
}
