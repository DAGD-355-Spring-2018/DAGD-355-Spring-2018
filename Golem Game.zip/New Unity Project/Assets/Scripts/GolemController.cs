﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GolemController : MonoBehaviour {

	public SizeState sizeState;
	public ElementalState elementalState;

	public GameObject pickup; // prefab of the pickup it drops
}
