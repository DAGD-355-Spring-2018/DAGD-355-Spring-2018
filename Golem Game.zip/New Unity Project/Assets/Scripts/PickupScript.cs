﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupScript : Interactable {

	public enum Element {Wax, Wood, Stone, Crystal};
	public Element element;


	private GameObject player;
	public bool isSmall;

	// Use this for initialization
	void Awake()
	{
		player = GameObject.Find("Clayton");
		//Debug.Log (player);
	}

	private void OnTriggerEnter(Collider other)
	{
		onTrigger ();
	}

	void OnTriggerStay(Collider other)
	{
		onTrigger ();
	}

	private void OnTriggerExit(Collider other)
	{
		//CameraController.isTriggered = false; // commented this out, this isn't necessary because of how this is set up
	}

	private void onTrigger() // needs to be refactored, Ben's got a better version.
	{
		bool isEligible;

		if(isSmall)
			isEligible = player.GetComponent<PlayerController>().gCon.sizeState.isEligibleWithSmall;
		else
			isEligible = player.GetComponent<PlayerController>().gCon.sizeState.isEligibleWithLarge;// checks if it is in the medium state, small and large cant pick this up
		
		if(isEligible) // if it matches up
		{
			CameraController.uiText.SetActive (true); 
			CameraController.isTriggered = true; // tells camera controller that there is atleast 1 pickup that is in range of the player
			if (Input.GetKeyDown(KeyCode.E))
			{
				if(isSmall)
					player.GetComponent<PlayerController>().gCon.sizeState.onSmallPickup(element);
				else
					player.GetComponent<PlayerController>().gCon.sizeState.onLargePickup(element); // calls the medium states on large pickup function (changes into large state)
				
				Destroy(gameObject);  // destroys this gameobject
			}
		}
	}

	public override void Interact (PlayerController p)
	{
		bool isEligible;

		if(isSmall)
			isEligible = p.gCon.sizeState.isEligibleWithSmall;
		else
			isEligible = p.gCon.sizeState.isEligibleWithLarge;// checks if it is in the medium state, small and large cant pick this up

		if(isEligible) // if it matches up
		{
			CameraController.uiText.SetActive (true); 
			CameraController.isTriggered = true; // tells camera controller that there is atleast 1 pickup that is in range of the player
			if (Input.GetKeyDown(KeyCode.E))
			{
				if(isSmall)
					p.gCon.sizeState.onSmallPickup(element);
				else
					p.gCon.sizeState.onLargePickup(element); // calls the medium states on large pickup function (changes into large state)

				Destroy(gameObject);  // destroys this gameobject
			}
		}
	}
}
