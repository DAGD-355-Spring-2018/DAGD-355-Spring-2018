﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CameraController : MonoBehaviour {

    public GameObject player;

	// text that pops up when player is in range of picking up a pickup
	public static GameObject uiText;
	public GameObject uiTextPub;

    public Vector3 offset;

	public static bool isTriggered = false;

	void Start() {
		uiText = uiTextPub; // quick work-around to make the uitext static
	}

	void FixedUpdate() {
		if (!isTriggered) // checks if the player is in range of any pickups, if it isn't it deactivates the text
			uiText.SetActive (false); 

		isTriggered = false; // resets to false so every frame there must be a pickup in range for the text to be displayed
	}
	
	// Update is called once per frame
	void LateUpdate () {

        transform.position = player.transform.position + offset; // just keeps the camera above the player
	}
}
