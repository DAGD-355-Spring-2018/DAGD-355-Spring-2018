﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MediumStateScript : SizeState {
    public float jumpStrength;

	// Use this for initialization
	void Start () {
		jumpSrength = 4f;
		isEligibleWithLarge = true;
		clayton = GameObject.Find ("Clayton");
	}

	public override void onLargePickup(PickupScript.Element element) // grows to large state
    {
		Vector3 pos = clayton.transform.position;
		PlayerController p = clayton.GetComponent<PlayerController>(); // reference to the player controller script

		GameObject obj;
		pos.y = .5f;
		p.bodyList [1].SetActive (false);
		switch (element) {
		case PickupScript.Element.Wax:
			obj = Instantiate(p.waxLargeBody, pos, Quaternion.identity, clayton.transform); // instantiates the large body at the players position
			workaround(obj, p);
			break;
		case PickupScript.Element.Wood:
			obj = Instantiate(p.woodLargeBody, pos, Quaternion.identity, clayton.transform); // instantiates the large body at the players position
			workaround(obj, p);
			break;
		case PickupScript.Element.Crystal:
			obj = Instantiate(p.crystalLargeBody, pos, Quaternion.identity, clayton.transform); // instantiates the large body at the players position
			workaround(obj, p);
			break;
		case PickupScript.Element.Stone:
			obj = Instantiate(p.stoneLargeBody, pos, Quaternion.identity, clayton.transform); // instantiates the large body at the players position
			workaround(obj, p);
			break;
		}
    }

	public override void eject()
	{
        GameObject.FindGameObjectWithTag("MainCamera").transform.Rotate(new Vector3(-30, 0, 0)); // rotates the camera down

		PlayerController p = clayton.GetComponent<PlayerController>(); // reference to the player controller script
        Vector3 pos = clayton.transform.position;

		GameObject obj1 = Instantiate(p.gCon.pickup, new Vector3(pos.x, .3f, pos.z), Quaternion.identity); // instantiates a new small pickup on the ground below the player
		//p.bodyList[1].SetActive(true);
    }
}
