﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WoodStateScript : ElementalState {

	public override void specialAbility()
	{
		Debug.Log ("Wood ability");
	}
}
