﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveableObject : Interactable {

	public Vector3 moveVector;

	private GameObject player;
	public bool isSmall;

	// Use this for initialization
	void Awake()
	{
		player = GameObject.Find("Clayton");
		//Debug.Log (player);
	}

	private void OnTriggerEnter(Collider other)
	{
		onTrigger ();
	}

	void OnTriggerStay(Collider other)
	{
		onTrigger ();
	}
		
	private void onTrigger() // needs to be refactored, Ben's got a better version.
	{
		if (Input.GetKeyDown(KeyCode.F))
		{
			transform.Translate (moveVector);
			moveVector *= -1;
		}
	}

	public override void Interact(PlayerController p)
	{
		transform.Translate (moveVector);
		moveVector *= -1;
	}
}
