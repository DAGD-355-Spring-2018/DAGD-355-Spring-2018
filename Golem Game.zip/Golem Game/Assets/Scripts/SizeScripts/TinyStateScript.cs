﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TinyStateScript : SizeState {


	// Use this for initialization
	void Start () {
		isEligibleWithSmall = true;
		clayton = GameObject.Find ("Clayton");
	}

	public override void onSmallPickup(PickupScript.Element element)
    {
		PlayerController p = clayton.GetComponent<PlayerController>(); // reference to the player controller script
		GameObject obj;
		Vector3 pos = clayton.transform.position;
		clayton.transform.position += new Vector3 (0f, 1f, 0f);

		pos.y = .5f;

		switch (element) {
		case PickupScript.Element.Wax:
			obj = Instantiate(p.waxMedBody, pos, Quaternion.identity, clayton.transform);//, gameObject.transform);
			workaround(obj, p);
			break;
		case PickupScript.Element.Wood:
			obj = Instantiate(p.woodMedBody, pos, Quaternion.identity, clayton.transform);
			workaround(obj, p);
			break;
		case PickupScript.Element.Crystal:
			obj = Instantiate(p.crystalMedBody, pos, Quaternion.identity, clayton.transform);//, gameObject.transform);
			workaround(obj, p);
			break;
		case PickupScript.Element.Stone:
			obj = Instantiate(p.stoneMedBody, pos, Quaternion.identity, clayton.transform);//, gameObject.transform);
			workaround(obj, p);
			break;
		}

        GameObject.FindGameObjectWithTag("MainCamera").transform.Rotate(new Vector3(30, 0, 0)); // rotates the camera down
    }
}
