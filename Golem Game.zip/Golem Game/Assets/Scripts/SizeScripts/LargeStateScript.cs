﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LargeStateScript : SizeState {

	void Start() {
		jumpSrength = 5f;
		clayton = GameObject.Find ("Clayton");
	}

	public override void eject()
    {
		Vector3 pos = clayton.transform.position;
		PlayerController p = clayton.GetComponent<PlayerController>(); // reference to the player controller script

		GameObject obj = Instantiate(p.gCon.pickup, new Vector3(pos.x, .35f, pos.z), Quaternion.identity); // spawns a new large pickup below the player
		p.bodyList[1].SetActive(true);
		//p.gCon.sizeState = (SizeState)mss; // changes the state to medium
    }
}
