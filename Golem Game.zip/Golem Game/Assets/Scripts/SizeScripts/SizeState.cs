﻿using UnityEngine;

public class SizeState : MonoBehaviour {

	public GameObject clayton;

	public float jumpSrength = 0;

	public bool isEligibleWithSmall = false;
	public bool isEligibleWithLarge = false;

    // called when the small pickup is picked up
	virtual public void onSmallPickup(PickupScript.Element element) {}  // these will eventually become one function, with Ben's refactor
	virtual public void onLargePickup(PickupScript.Element element) {}

	virtual public void eject() {}

    virtual public void ability() { }

    protected void workaround(GameObject obj, PlayerController p)
    {
        p.bodyList.Add(obj);
        p.UpdateCurrentState();
    }
}
