﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LevelSelectScript : MonoBehaviour {

	public GameObject canvasToOpen;
	public GameObject currentCanvas;
	public Color grayedOut;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

	public void onClick() {
		canvasToOpen.SetActive (true);
		currentCanvas.SetActive (false);

		BoolPlayerPrefs.SetBool ("Level1", true);
		int i;
		for (i = 1; i <= 5; ++i) {
			bool completed = BoolPlayerPrefs.GetBool ("Level" + i.ToString(), false);
			if (completed) {
				GameObject obj = GameObject.Find ("Level" + i.ToString() + "Button");
				obj.GetComponentInChildren<Text>().text = "Replay Level " + i.ToString();
				obj.GetComponentInChildren<Text> ().fontSize -= 2;
			} else
				break;
		}
		++i;
		for (;i <= 5; ++i) {
			GameObject obj = GameObject.Find ("Level" + i.ToString() + "Button");
			obj.GetComponent<Image>().color = grayedOut;
		}
	}
}
