﻿ using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayAudio : MonoBehaviour {

    public AudioClip jump;
	public AudioClip[] myLoop;
	private AudioSource source;
	public bool shouldPlay = false;
	private bool isPlaying = false;


	// Use this for initialization
	void Start () {
		source = GetComponent<AudioSource>();
		source.clip = myLoop [2];
	}
	
	// Update is called once per frame
	void Update () {
		if (PlayerControllerV2.isLarge == true) {
			if (shouldPlay && !isPlaying) {
				source.loop = true;
				//source.clip = myLoop [0];
				source.Play ();
				isPlaying = true;
			}
				
			if (shouldPlay == false ) {
				source.Stop ();
			}


		}
		if (PlayerControllerV2.isMed == true) {

			if (shouldPlay && !isPlaying) {
				print ("Im med");
				source.loop = true;
				//source.clip = myLoop [1];
				source.Play ();
				isPlaying = true;
			}
			if (shouldPlay == false) {
				source.Stop ();
			}

		}
		if (PlayerControllerV2.isSmall == true) {
			if (shouldPlay && !isPlaying) {
				source.loop = true;
				//source.clip = myLoop [2];
				source.Play ();
				isPlaying = true;
			}
			if (shouldPlay == false) {
				source.Stop ();
			}

		}
		isPlaying = shouldPlay;
	}

	public void switchTrack(int playerState) {
		source.Stop ();
		source.clip = myLoop[playerState];

			source.Play ();
	}
    public void playJump()
    {
        shouldPlay = true;
        source.Stop();
        source.clip = jump;
        source.Play();
        //shouldPlay = false;
    }
}

