﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Reset : MonoBehaviour {

    public GameObject alter; //object that clayton can reset piles and himself
    public GameObject player; // player ref

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        if(Vector3.Distance(alter.transform.position, player.transform.position) < 2) //checks to see if clayton is close to the alter
        {
            if (Input.GetKeyUp(KeyCode.E)) //checks to see if the e key was pressed
            {

                try
                {
                    //reset the piles
                    PileLocations piles = GetComponent<PileLocations>();
                    piles.ResetPileLocations();
                }
                catch {  }
            }
        }
	}
}
