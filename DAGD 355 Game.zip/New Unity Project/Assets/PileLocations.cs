﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PileLocations : MonoBehaviour {

    public GameObject claton; //good ole' clayton
    public GameObject smallPilePrefab; //small pile
    public GameObject largePilePrefab; //large pile
    public List<GameObject> listOfPiles; //list to store all of the piles in the level
    public List<Vector3> pileLocations = new List<Vector3>(); //list to store the location of all of the piles originally spawned in the level
    public List<bool> sizeOfPile; //True == small, False == large
    public bool claytonSize = true; //true == clayton, false == medium or large golem
    

	// Use this for initialization
	void Start () {

        getPiles(); //gets all of the pickup piles in the level

		for(int k = 0; k < listOfPiles.Count; k++) //loop that runs through all of the piles
        {
            //get the location of all the piles in the level
            pileLocations.Add(listOfPiles[k].transform.position);

            //sets whether the pile is large or small
            if(listOfPiles[k].tag == "SmallPickup")
            {
                sizeOfPile.Add(true); //small pile
            }
            else
            {
                sizeOfPile.Add(false); //large pile
            }
        }
	}
	
	// Update is called once per frame
	void Update () {

        getPiles(); //gets all the piles every frame so if clayton sheds a layer, it adds it to the list of piles

        for(int i = 0;  i < listOfPiles.Count;  i++) //runs through the piles
        {
            if(listOfPiles[i] == null) //checks to see if the pile exists, for instance if clayton picks a pile up
            {
                listOfPiles.RemoveAt(i); //if its not there, remove it
            }
        }
    }

    private void getPiles() //gets all the piles in the level
    {
        List<GameObject> tempList = new List<GameObject>(GameObject.FindGameObjectsWithTag("LargePickup")); //finds all the pickups with the tag "LargePickup" and creates a temp list for them
        listOfPiles = new List<GameObject>(GameObject.FindGameObjectsWithTag("SmallPickup")); //resets and creates a new list of piles with objects with the tag "SmallPickup"

        for(int i = 0; i <= tempList.Count - 1; i++) //runs through the temp list that contains the large pickups
        {
            listOfPiles.Add(tempList[i]); //adds the large pick ups to the small pick ups to create a single list of all of the pickups
        }
    }

    public void ResetPileLocations() //resets the piles and resets clayton back to the tiny state
    {

        if (claytonSize == false) //checks to see if clayton is not tiny
        {
            if (GameObject.Find("LargeBody(Clone)") != null) //checks to see if clayton has a large body
            {
                claton.GetComponent<LargeStateScript>().eject(); //eject clayton from his large body
            }
        }

        if (claytonSize == false) //checks to see if clayton is not tiny
        {
            if (GameObject.Find("MedBody(Clone)") != null) //checks to see if clayton has a medium body
            {
                claton.GetComponent<MediumStateScript>().eject(); //eject clayton from his medium body

                claytonSize = true;
            }
        }

        getPiles(); //gets all the piles one last time for the reset

        foreach(GameObject i in listOfPiles) //runs through the piles list to delete them
        {
            Destroy(i); //kills the piles, deader than dead
        }

         for(int k = 0; k < sizeOfPile.Count; k++) //runs through the pile size list since it saved how many piles were orginially spawned
         {
             if(sizeOfPile[k] == true) //checks to see if its small or large
             {
                 Instantiate(smallPilePrefab, pileLocations[k], Quaternion.identity); //if small, spawn a small pile at the pile location saved in the pileLocation list
             }
             else
             {
                 Instantiate(largePilePrefab, pileLocations[k], Quaternion.identity); //if large, spawn a large pile at the pile location saved in the pileLocation list
            }
         }



        

    }
}
