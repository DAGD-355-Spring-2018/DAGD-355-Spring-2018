# DAGD-355-Spring-2018

Basic example of jumping/changing states. Will update soon to include elemental states, too. Read the comment at the top of the Camera Controller Script for a summary of how it works.