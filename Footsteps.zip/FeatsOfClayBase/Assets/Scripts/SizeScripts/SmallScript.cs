﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SmallScript : SizeScript {

	public override void Action()
	{
		Debug.Log("Small Action");
	}
}
