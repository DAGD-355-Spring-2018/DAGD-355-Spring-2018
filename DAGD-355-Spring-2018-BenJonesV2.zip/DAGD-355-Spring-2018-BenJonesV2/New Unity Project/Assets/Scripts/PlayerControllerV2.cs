﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControllerV2 : MonoBehaviour {
	public GolemController gCon;
	public GameObject currentState;
	public GameObject stateHolder;
	public List<GameObject> bodyList;
	public float speed = 10;
	float moveX;
	float moveY;

	Rigidbody rb;

	// Use this for initialization
	void Start () {
		rb = GetComponent<Rigidbody>();
		UpdateCurrentState();
	}
	
	// Update is called once per frame
	void Update () {
		if (Input.GetButtonDown("Fire1"))
		{
			gCon.eState.Action();
			//bodyList[bodyList.Count - 1].eState.Action();
		}
		if (Input.GetButtonDown("Fire2"))
		{
			gCon.sState.Action();
			//bodyList[bodyList.Count - 1].sState.Action();
		}
		if(Input.GetButtonDown("Jump"))
		{
			Eject();
		}
		moveX = Input.GetAxis("Horizontal");
		moveY = Input.GetAxis("Vertical");
	}
	void FixedUpdate()
	{
		rb.AddForce(new Vector3(moveX,0, moveY) * speed);
	}
	public void OnCollisionStay(Collision c)
	{
		if(c.transform.tag == "Interactable")
		{
			//Debug.Log("touching interactable");
			if (Input.GetButton("Fire3"))
			{
				c.transform.GetComponent<Interactable>().Interact(this);
				//Debug.Log("pickup");
			}
		}

	}

	public void PickupBody(GameObject go, int size)
	{
			GameObject tempGO = Instantiate(go, transform.position, transform.rotation, transform);
			bodyList.Add(tempGO);
			UpdateCurrentState();
	}
	public void Eject()
	{
		gCon.Eject();
		rb.velocity += Vector3.up * gCon.sState.ejectStrength;
		if (bodyList.Count > 1)
		{
			bodyList.RemoveAt(bodyList.Count - 1);
			Destroy(currentState);
			UpdateCurrentState();
		}
	}

	public void UpdateCurrentState()
	{
		currentState = bodyList[bodyList.Count - 1];
		gCon = currentState.GetComponent<GolemController>();
	}
}
