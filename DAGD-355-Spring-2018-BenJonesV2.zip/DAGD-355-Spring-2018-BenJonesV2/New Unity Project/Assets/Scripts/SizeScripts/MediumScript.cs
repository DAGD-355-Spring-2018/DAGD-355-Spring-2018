﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MediumScript : SizeScript {

	public override void Action()
	{
		Debug.Log("Medium Action");
	}
}
