﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WoodCollider : MonoBehaviour {

    // Enlarges player when touches the wood box.
    // Applies the wooden state needed to burn.






    public Rigidbody rb;

	// Use this for initialization
	void Start () {
        rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnTriggerEnter(Collider other)
    {
        
            Debug.Log(gameObject.name + " was triggered by " + other.gameObject.name);
            other.gameObject.GetComponent<Renderer>().material.color = Color.magenta;
        if (PlayerController.small == true)
        {
            PlayerController.med = true;
            PlayerController.small = false;
            PlayerController.large = false;
        }
        if (PlayerController.med == true)
        {
            PlayerController.large = true;
            PlayerController.med = false;
            PlayerController.small = false;
        }
        PlayerController.wooden = true;

        
    }
}
