﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireCollider : MonoBehaviour {

    /*
     Enables the burning state when the player collides with the fire box and sets burn time according to player size.
     */





    
    private Rigidbody rb;

    // Use this for initialization
    void Start () {
        rb = GetComponent<Rigidbody>();
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnTriggerEnter(Collider other)
    {
        
            if (PlayerController.wooden == true)
            if (PlayerController.small == true) { }

            if (PlayerController.med == true) {
            PlayerController.burning = true;
            PlayerController.burnTime = 4f;
        }
            if (PlayerController.large == true)
            {
                other.gameObject.GetComponent<Renderer>().material.color = Color.red;
                PlayerController.burning = true;
                PlayerController.burnTime = 10.0f;
            }
        
    }
}
