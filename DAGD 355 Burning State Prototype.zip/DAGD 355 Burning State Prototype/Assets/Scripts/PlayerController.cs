﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{
    /*
    Changes scale of player when touches wood, and applies the wooden state needed to burn.
    if the player touches the fire box while wooden, the movement speed is increased and player cannot stop velocity.
    After burning for 6 seconds in the large form, the player shrinks to medium form where they burn for another 4 seconds before shrinking again and losing their wooden state.
    If a player extinguishes themselves before the burning timer expires, they keep the wooden state and can reignite themselves.
    Larger state burns longer than medium state.
    Small state cannot burn.
    */
    private Vector3 velocity = new Vector3();
    public float speed;
    public static bool small = true;
    public static bool med = false;
    public static bool large = false;
    public static bool wooden = false;
    public static bool burning = false;
    public static float burnTime;
    public Rigidbody rb;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        Renderer rend = GetComponent<Renderer>();
    }

    void FixedUpdate()
    {
        float moveHorizontal = (Mathf.Abs(rb.velocity.x) < speed) ? Input.GetAxis("Horizontal") : 0;
        float moveVertical = (Mathf.Abs(rb.velocity.z) < speed) ? Input.GetAxis("Vertical") : 0;

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        rb.velocity += movement;

        if (small == true)
        {
            transform.localScale = new Vector3(1, 1, 1);
        }
        if (med == true)
        {
            transform.localScale = new Vector3(2, 2, 2);
        }
        if (large == true)
        {
            transform.localScale = new Vector3(3, 3, 3);
        }

        if (burning == false){
            rb.drag = 5;
            speed = 2;
       
        }
        if (burning == true)
        {

            if (burnTime >= 0)
            {
                speed = 5;
                rb.drag = 1/100;
                burnTime -= Time.deltaTime;
                if(burnTime > 4)
                {
                    large = true;
                    small = false;
                    med = false;
                }
                if(burnTime <= 4 && burnTime > 0)
                {
                    med = true;
                    small = false;
                    large = false;
                }
            }


            if (burnTime <= 0)
            {
                burning = false;
                wooden = false;
                small = true;
                large = false;
                med = false;
            }
        }
        if (wooden == true)
        {
            print(burnTime);
        }
    }
}
 