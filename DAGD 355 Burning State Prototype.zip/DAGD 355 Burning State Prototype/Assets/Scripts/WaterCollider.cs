﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaterCollider: MonoBehaviour {

    // Extinguishes player if on fire.



    private Rigidbody rb;

    // Use this for initialization
    void Start() {
        rb = GetComponent<Rigidbody>();
    }

        
	
	
	// Update is called once per frame
	void Update () {
		
	}
    private void OnTriggerEnter(Collider other)
    {
     
            if (PlayerController.burning == true)
            {
                PlayerController.burning = false;
            }
        }
    }

