﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour
{

    private Vector3 velocity = new Vector3();
    public float speed = 25;
    bool burning = false;
    float burnTime;
    //private Rigidbody rb;

    void Start()
    {
        //rb = GetComponent<Rigidbody>();
        Renderer rend = GetComponent<Renderer>();
    }

    void FixedUpdate()
    {
        float xDir = 0;
        float zDir = 0;
        float yDir = 0;

        if (burning == false){

            gameObject.GetComponent<Renderer>().material.color = Color.gray;

            if (Input.GetKey(KeyCode.A))
                xDir--;
            if (Input.GetKey(KeyCode.D))
                xDir++;
            if (Input.GetKey(KeyCode.W))
                zDir++;
            if (Input.GetKey(KeyCode.S))
                zDir--;
            if (Input.GetKey(KeyCode.Space))
                burning = true;

            burnTime = 10.0f;
        }
        if (burning == true)
        {

            gameObject.GetComponent<Renderer>().material.color = Color.red;

            if (burnTime >= 0)
            {
                   if (Input.GetKey(KeyCode.A))
                       xDir -= 2;
                   if (Input.GetKey(KeyCode.D))
                       xDir += 2;
                  if (Input.GetKey(KeyCode.W))
                       zDir += 2;
                   if (Input.GetKey(KeyCode.S))
                       zDir -= 2;
            }
            burnTime -= Time.deltaTime;
            if (burnTime <= 0)
            {
                burning = false;
            }
        }
        print(burnTime);
            Vector3 dir = new Vector3(xDir, yDir, zDir);

        velocity += dir * speed * Time.deltaTime;
        transform.position += velocity * Time.deltaTime;
        velocity *= 0.9f;

        //        float moveHorizontal = Input.GetAxis("Horizontal");
        //        float moveVertical = Input.GetAxis("Vertical");
        //
        //        Vector3 movement = new Vector3 (moveHorizontal ,0.0f,moveVertical );

        // rb.AddForce(movement * speed);
    }
    void OnTriggerEnter(Collider other)
    {
        //      if (other.gameObject.CompareTag("Pick Up"))
        //       {
        //           other.gameObject.SetActive(false);
        //       }
        //   }
    }
}
 