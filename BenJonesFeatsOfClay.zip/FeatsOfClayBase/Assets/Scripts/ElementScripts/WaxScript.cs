﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WaxScript :ElementScript {

	public override void Action()
	{
		Debug.Log("Wax Action");
	}
}
