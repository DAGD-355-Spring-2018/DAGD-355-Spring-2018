﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ClayScript : ElementScript {

	public override void Action()
	{
		Debug.Log("Clay Action");
	}
}
