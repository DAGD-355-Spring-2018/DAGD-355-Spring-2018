﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PickupScript : Interactable {
	public GameObject gBody;

	public override void Interact() // we need to check if the player's state is correct, but this is the general idea.
	{
		Camera.main.GetComponent<GameController>().clayton.GetComponent<PlayerControllerV2>().PickupBody(gBody);
		Debug.Log("Interacted with a pickup");
		Destroy(this.gameObject);
	}
}
